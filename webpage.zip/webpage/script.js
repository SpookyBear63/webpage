var li_elements = document.querySelectorAll(".wrapper_left ul li");
var item_elements = document.querySelectorAll(".item");
for (var i = 0; i < li_elements.length; i++) {
  li_elements[i].addEventListener("click", function() {
    li_elements.forEach(function(li) {
      li.classList.remove("active");
    });
    this.classList.add("active");
    var li_value = this.getAttribute("data-li");
    item_elements.forEach(function(item) {
      item.style.display = "none";
    });
    if (li_value == "importanttoknow") {
      document.querySelector("." + li_value).style.display = "block";
    } else if (li_value == "step1") {
      document.querySelector("." + li_value).style.display = "block";
    } else if (li_value == "step2") {
      document.querySelector("." + li_value).style.display = "block";
    } else if (li_value == "step3") {
      document.querySelector("." + 
li_value).style.display = "block";
    } else if (li_value == "step4") {
      document.querySelector("." + 
 li_value).style.display = "block";
    } else if (li_value == "graph") {
      document.querySelector("." +                   
li_value).style.display = "block";
    } else {
      console.log("");
    }
  });
}
function myFunction(divid) {

  var x = document.getElementById(divid);  
  
  if (x.style.display == "none") 
  {
    x.style.display = "block";
  } 
  else {
    x.style.display = "none";
  }  
}
function drag_start(event) {
	var style = window.getComputedStyle(event.target, null);
	event.dataTransfer.setData("text/plain", (parseInt(style.getPropertyValue("left"), 10) - event.clientX) + ',' + (parseInt(style.getPropertyValue("top"), 10) - event.clientY) + ',' + event.target.getAttribute('data-item'));
}

function drag_over(event) {
	event.preventDefault();
	return false;
}

function drop(event) {
	var offset = event.dataTransfer.getData("text/plain").split(',');
	var dm = document.getElementsByClassName('dragme');
	dm[parseInt(offset[2])].style.left = (event.clientX + parseInt(offset[2], 10)) + 'px';
	dm[parseInt(offset[2])].style.top = (event.clientY + parseInt(offset[1], 10)) + 'px';
		dm[parseInt(offset[2])].style.left = (event.clientX + parseInt(offset[0], 10)) + 'px';
		dm[parseInt(offset[2])].style.top = (event.clientY + parseInt(offset[3], 10)) + 'px';
		dm[parseInt(offset[2])].style.left = (event.clientX + parseInt(offset[4], 10)) + 'px';
	event.preventDefault();
	return false;
}

var dm = document.getElementsByClassName('dragme');
for (var i = 0; i < dm.length; i++) {
	dm[i].addEventListener('dragstart', drag_start, false);
	document.body.addEventListener('dragover', drag_over, false);
	document.body.addEventListener('drop', drop, false);
}